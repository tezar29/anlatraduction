import 'package:flutter/material.dart';
import '../providers/app_state.dart' show ConversationMicState;

/// Barre de saisie facon chat : champ arrondi + bouton micro (push-to-talk)
/// qui bascule vers l'envoi des que le champ contient du texte tape.
///
/// Le bouton reflete directement `ConversationMicState` :
///   idle/waiting  -> pret, appui possible
///   recording     -> maintenu, ecoute en cours
///   processing    -> relache, transcription en cours
///   translating   -> traduction en cours
///   playing       -> lecture de la traduction en cours
class ChatComposer extends StatefulWidget {
  final TextEditingController controller;
  final ConversationMicState micState;
  final int recordingSeconds;
  final String lastRecordedText;
  final VoidCallback? onStartRecording;
  final VoidCallback? onStopRecording;
  final VoidCallback onSend;

  const ChatComposer({
    super.key,
    required this.controller,
    required this.micState,
    required this.recordingSeconds,
    this.lastRecordedText = '',
    this.onStartRecording,
    this.onStopRecording,
    required this.onSend,
  });

  @override
  State<ChatComposer> createState() => _ChatComposerState();
}

class _ChatComposerState extends State<ChatComposer> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_onTextChanged);
    super.dispose();
  }

  void _onTextChanged() => setState(() {});

  String? _statusLabel() {
    switch (widget.micState) {
      case ConversationMicState.recording:
        final secs = widget.recordingSeconds.toString().padLeft(2, '0');
        return 'Enregistrement 00:$secs — relâchez pour envoyer';
      case ConversationMicState.processing:
        return 'Transcription en cours…';
      case ConversationMicState.translating:
        return 'Traduction en cours…';
      case ConversationMicState.playing:
        return 'Lecture de la traduction…';
      case ConversationMicState.idle:
      case ConversationMicState.waiting:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hasText = widget.controller.text.trim().isNotEmpty;
    final isRecording = widget.micState == ConversationMicState.recording;
    final isBlocked = widget.micState == ConversationMicState.processing ||
        widget.micState == ConversationMicState.translating ||
        widget.micState == ConversationMicState.playing;
    final statusLabel = _statusLabel();
    final statusColor = isRecording
        ? Colors.redAccent
        : (isBlocked ? scheme.primary : scheme.outline);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (statusLabel != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (isRecording) ...[
                  const Icon(Icons.circle, size: 9, color: Colors.redAccent),
                  const SizedBox(width: 6),
                ] else if (isBlocked) ...[
                  SizedBox(
                    width: 12,
                    height: 12,
                    child: CircularProgressIndicator(strokeWidth: 2, color: statusColor),
                  ),
                  const SizedBox(width: 6),
                ],
                Text(
                  statusLabel,
                  style: TextStyle(fontWeight: FontWeight.w700, color: statusColor, fontSize: 12),
                ),
              ],
            ),
          )
        else if (!hasText && widget.onStartRecording != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              'Maintenez le micro pour parler',
              style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic, color: scheme.outline),
            ),
          )
        else if (widget.lastRecordedText.isNotEmpty && !hasText)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              'Dernier envoi : ${widget.lastRecordedText}',
              style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic, color: scheme.outline),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: Container(
                constraints: const BoxConstraints(minHeight: 46),
                padding: const EdgeInsets.symmetric(horizontal: 6),
                decoration: BoxDecoration(
                  color: scheme.surfaceContainerHighest.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(
                      child: TextField(
                        controller: widget.controller,
                        textInputAction: TextInputAction.send,
                        onSubmitted: (_) => widget.onSend(),
                        maxLines: 4,
                        minLines: 1,
                        decoration: const InputDecoration(
                          hintText: 'Écrire un message…',
                          border: InputBorder.none,
                          isCollapsed: true,
                          contentPadding: EdgeInsets.symmetric(vertical: 13, horizontal: 10),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            _CircleButton(
              icon: hasText
                  ? Icons.send_rounded
                  : (isBlocked ? Icons.mic_off_rounded : Icons.mic_rounded),
              background: hasText
                  ? scheme.primary
                  : (isBlocked
                      ? scheme.surfaceContainerHighest
                      : (isRecording ? Colors.redAccent : scheme.secondary)),
              foreground: hasText || isRecording
                  ? Colors.white
                  : (isBlocked ? scheme.outline : scheme.onSecondary),
              onTap: hasText ? widget.onSend : null,
              onPointerDown: !hasText && !isBlocked && widget.onStartRecording != null
                  ? (_) => widget.onStartRecording!()
                  : null,
              onPointerUp: !hasText && !isBlocked && widget.onStopRecording != null
                  ? (_) => widget.onStopRecording!()
                  : null,
              onPointerCancel: !hasText && !isBlocked && widget.onStopRecording != null
                  ? (_) => widget.onStopRecording!()
                  : null,
            ),
          ],
        ),
      ],
    );
  }
}

class _CircleButton extends StatelessWidget {
  final IconData icon;
  final Color background;
  final Color foreground;
  final VoidCallback? onTap;
  final void Function(PointerDownEvent)? onPointerDown;
  final void Function(PointerUpEvent)? onPointerUp;
  final void Function(PointerCancelEvent)? onPointerCancel;

  const _CircleButton({
    required this.icon,
    required this.background,
    required this.foreground,
    required this.onTap,
    this.onPointerDown,
    this.onPointerUp,
    this.onPointerCancel,
  });

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: onPointerDown,
      onPointerUp: onPointerUp,
      onPointerCancel: onPointerCancel,
      child: Material(
        color: background,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Icon(icon, color: foreground, size: 22),
          ),
        ),
      ),
    );
  }
}
