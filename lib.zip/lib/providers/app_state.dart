import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/language.dart';
import '../models/backend_models.dart';
import '../models/translation_entry.dart';
import '../services/backend_service.dart';
import '../services/guest_session_service.dart';
import '../services/language_pack_service.dart';
import '../services/translation_service.dart';
import '../services/voice_service.dart';

/// États du bouton micro en conversation (push-to-talk), suivant
/// exactement le cycle : appui → parole → relâchement → transcription →
/// traduction → lecture → attente du tour suivant.
enum ConversationMicState {
  idle, // Rien ne se passe, prêt à appuyer
  recording, // Doigt maintenu, écoute en cours
  processing, // Relâché : on récupère le texte capté (transcription)
  translating, // Envoi au backend pour traduction
  playing, // Lecture à voix haute de la traduction
  waiting, // Tour terminé, on attend que l'autre participant parle
}

class AppState extends ChangeNotifier {
  AppState({
    required this.translationService,
    required this.voiceService,
    required this.backend,
  }) {
    _initSystemMicMonitor();
  }

  final TranslationService translationService;
  final VoiceService voiceService;
  final BackendService backend;

  bool isAuthenticated = false;
  bool isSessionLoading = false;
  String? sessionError;
  UserProfile? profile;
  Entitlements? entitlements;
  UserSubscription? subscription;
  List<SubscriptionPlan> availablePlans = [];
  List<BillingInvoice> invoices = [];
  List<PaymentRecord> payments = [];
  List<Conversation> conversations = [];
  Conversation? activeConversation;
  List<Speaker> speakers = [];
  List<Map<String, dynamic>> timeline = [];
  Map<String, dynamic> conversationUsage = {};
  List<LanguagePack> availableLanguagePacks = [];
  List<LanguagePack> recommendedLanguagePacks = [];
  List<LanguagePackInstallation> installedLanguagePacks = [];
  GuestSession? guestSession;
  Map<String, dynamic> guestDailyUsage = {};
  String? refreshToken;

  // --- États de saisie indépendants ---
  String inputText = '';
  String conversationInputText = '';
  String outputText = '';
  String lastRecordedText = '';
  final Map<int, String> _localOriginals = {};
  Map<int, String> get localOriginals => _localOriginals;

  bool isTranslating = false;
  bool isListening = false;
  bool _isAutoRestarting = false;
  bool _isTranslateMode = true;
  bool _conversationScreenActive = false;

  // --- Machine à états du micro de conversation (push-to-talk) ---
  // Remplace l'ancien jeu de booléens séparés (_conversationTurnInProgress,
  // _conversationTtsInProgress, _conversationReleaseInProgress,
  // _conversationStartInProgress) par un seul état faisant foi à chaque
  // instant, conforme au schéma demandé.
  ConversationMicState conversationMicState = ConversationMicState.idle;

  void _setConversationMicState(ConversationMicState state) {
    conversationMicState = state;
    notifyListeners();
  }

  /// Le bouton micro est désactivé (appui ignoré) pendant le traitement,
  /// la traduction et la lecture — mais PAS pendant `recording`, où il
  /// doit rester réactif pour détecter le relâchement du doigt.
  bool get isConversationMicBlocked =>
      conversationMicState == ConversationMicState.processing ||
      conversationMicState == ConversationMicState.translating ||
      conversationMicState == ConversationMicState.playing;

  // États pour l'appui prolongé (Push-to-talk)
  bool _conversationHoldActive = false;
  int _conversationCaptureGeneration = 0;
  String _pendingConversationText = '';

  void _initSystemMicMonitor() {
    voiceService.setStatusListener((status) {
      debugPrint("System Mic Status: $status");
      if ((status == 'done' || status == 'notListening') && isListening && !_isAutoRestarting) {
        isListening = false;
        _stopRecordingTimer();
        notifyListeners();
      }
    });
  }

  void setConversationScreenActive(bool active) {
    _conversationScreenActive = active;
    if (!active && !_isTranslateMode) {
      stopAllListening();
      conversationMicState = ConversationMicState.idle;
    }
  }

  void setInputText(String text) {
    inputText = text;
    notifyListeners();
  }

  void setConversationInputText(String text) {
    conversationInputText = text;
    notifyListeners();
  }

  // --- Gestion de l'audio ---
  int recordingSeconds = 0;
  Timer? _recordingTimer;

  void _startRecordingTimer() {
    _recordingTimer?.cancel();
    recordingSeconds = 0;
    _recordingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      recordingSeconds++;
      notifyListeners();
    });
  }

  void _stopRecordingTimer() {
    _recordingTimer?.cancel();
    _recordingTimer = null;
    recordingSeconds = 0;
    notifyListeners();
  }

  Future<void> stopAllAudio() async {
    _isAutoRestarting = false;
    await voiceService.stopListening();
    await voiceService.stopSpeaking();
    if (isListening) {
      _stopRecordingTimer();
      isListening = false;
      notifyListeners();
    }
  }

  void stopAllListening() {
    unawaited(stopAllAudio());
  }

  // --- Langues ---
  AppLanguage sourceLang = AppLanguage.turkish;
  AppLanguage targetLang = AppLanguage.french;

  void swapLanguages() {
    final tmp = sourceLang;
    sourceLang = targetLang;
    targetLang = tmp;
    notifyListeners();
  }

  void setSourceLang(AppLanguage lang) {
    sourceLang = lang;
    notifyListeners();
  }

  void setTargetLang(AppLanguage lang) {
    targetLang = lang;
    notifyListeners();
  }

  void _syncLanguagesWithProfile() {
    if (profile == null) return;
    final prefCode = profile!.preferredLanguage.toLowerCase();
    try {
      final match = AppLanguage.all.firstWhere(
        (l) => l.code.toLowerCase() == prefCode,
      );
      sourceLang = match;
      if (targetLang.code == sourceLang.code) {
        targetLang = AppLanguage.all.firstWhere(
          (l) => l.code != sourceLang.code,
          orElse: () => AppLanguage.turkish,
        );
      }
    } catch (_) {}
  }

  // --- Authentification ---
  Future<void> login(String email, String password) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      final result = await backend.login(email, password);
      final accessToken = (result['accessToken'] ?? result['token'] ?? result['access_token'])?.toString();
      final incomingRefreshToken = (result['refreshToken'] ?? result['refresh_token'] ?? result['refreshTokenValue'])?.toString();

      if ((accessToken == null || accessToken.isEmpty) && (incomingRefreshToken == null || incomingRefreshToken.isEmpty)) {
        throw Exception('Aucun jeton d\'authentification reçu.');
      }

      backend.accessToken = accessToken ?? backend.accessToken;
      refreshToken = incomingRefreshToken?.isNotEmpty == true ? incomingRefreshToken : refreshToken;

      profile = await backend.profile();
      _syncLanguagesWithProfile();

      try {
        entitlements = await backend.entitlements();
        subscription = await backend.currentSubscription();
        conversations = await backend.conversations();
      } catch (_) {}

      isAuthenticated = true;
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> register({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String primaryLanguage,
    required String country,
    required String timezone,
  }) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      final result = await backend.register(
        email: email,
        password: password,
        firstName: firstName,
        lastName: lastName,
        primaryLanguage: primaryLanguage,
        country: country,
        timezone: timezone,
      );

      final accessToken = (result['accessToken'] ?? result['token'] ?? result['access_token'])?.toString();
      if (accessToken != null && accessToken.isNotEmpty) {
        backend.accessToken = accessToken;
        profile = await backend.profile();
        _syncLanguagesWithProfile();
        isAuthenticated = true;
      }
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    stopAllListening();
    if (refreshToken?.isNotEmpty == true) {
      try {
        await backend.logout(refreshToken!);
      } catch (_) {}
    }
    backend.accessToken = null;
    refreshToken = null;
    profile = null;
    isAuthenticated = false;
    notifyListeners();
  }

  Future<void> resendVerification(String email) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      await backend.resendVerification(email: email);
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> verifyEmail({required String email, required String code}) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      await backend.verifyEmail(email: email, code: code);
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> requestPasswordReset(String email) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      await backend.forgotPassword(email: email);
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> resetPassword({
    required String email,
    required String code,
    required String newPassword,
  }) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      await backend.resetPassword(
        email: email,
        code: code,
        newPassword: newPassword,
      );
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateProfile({
    String? fullName,
    String? preferredLanguage,
    String? country,
    String? timezone,
  }) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      final updated = await backend.updateProfile(
        fullName: fullName,
        preferredLanguage: preferredLanguage,
        country: country,
        timezone: timezone,
      );
      profile = updated;
      await refreshAccount();
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> changePlan(String planCode) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      subscription = await backend.changePlan(planCode);
      entitlements = await backend.entitlements();
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> upgradePlan(String planCode) async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      final updated = await backend.changePlan(planCode);
      subscription = updated;

      final invoice = await backend.createInvoice(subscriptionId: updated.id);
      if (invoice.id.isNotEmpty) {
        final payment = await backend.createPayment(
          invoiceId: invoice.id,
          provider: 'stripe',
          amount: invoice.amount,
          currency: invoice.currency,
        );
        if (payment.id.isNotEmpty) {
          await backend.confirmPayment(payment.id);
        }
      }

      entitlements = await backend.entitlements();
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> cancelSubscription() async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      subscription = await backend.cancelSubscription();
      entitlements = await backend.entitlements();
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> renewSubscription() async {
    isSessionLoading = true;
    sessionError = null;
    notifyListeners();
    try {
      subscription = await backend.renewSubscription();
      entitlements = await backend.entitlements();
    } catch (error) {
      sessionError = error.toString().replaceFirst('Exception: ', '');
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> createGuestSession({
    required String deviceId,
    required String displayName,
    required String sourceLanguage,
    required String targetLanguage,
  }) async {
    final service = GuestSessionService(
      baseUrl: 'https://api.anla.mybestsejour.com',
    );
    try {
      guestSession = await service.createSession(
        deviceId: deviceId,
        displayName: displayName,
        sourceLanguage: sourceLanguage,
        targetLanguage: targetLanguage,
      );
      guestDailyUsage = await service.checkDailyUsage(guestSession!.id);
      notifyListeners();
    } catch (_) {
      sessionError = 'Impossible de créer la session invitée.';
      notifyListeners();
    }
  }

  Future<void> loadGuestDailyUsage() async {
    if (guestSession == null) return;
    final service = GuestSessionService(
      baseUrl: 'https://api.anla.mybestsejour.com',
    );
    try {
      guestDailyUsage = await service.getDailyUsage(guestSession!.id);
    } catch (_) {
      guestDailyUsage = {};
    }
    notifyListeners();
  }

  Future<void> installLanguagePack(AppLanguage language) async {
    final packService = LanguagePackService(
      baseUrl: 'https://api.anla.mybestsejour.com',
      accessToken: backend.accessToken,
    );
    try {
      await packService.installPack(
        languageCode: language.code,
        deviceId: 'mobile-device',
        installedVersion: '1.0.0',
      );
      await loadLanguagePacks(service: packService);
    } catch (_) {
      sessionError = 'Erreur installation pack.';
      notifyListeners();
    }
  }

  Future<void> uninstallLanguagePack(AppLanguage language) async {
    final packService = LanguagePackService(
      baseUrl: 'https://api.anla.mybestsejour.com',
      accessToken: backend.accessToken,
    );
    try {
      await packService.uninstallPack(language.code);
      await loadLanguagePacks(service: packService);
    } catch (_) {
      sessionError = 'Erreur désinstallation pack.';
      notifyListeners();
    }
  }

  // --- Profil ---
  Future<void> refreshAccount() async {
    try {
      profile = await backend.profile();
      _syncLanguagesWithProfile();
    } catch (_) {}
    notifyListeners();
  }

  // --- Mode Traducteur ---
  Future<void> toggleMic() async {
    if (isListening) {
      stopAllListening();
      return;
    }

    _isTranslateMode = true;

    try {
      if (!voiceService.isAvailable) {
        await voiceService.init(onError: _handleVoiceError);
      }
      if (!voiceService.isAvailable) throw Exception('Micro non disponible');
    } catch (e) {
      sessionError = e.toString();
      notifyListeners();
      return;
    }

    isListening = true;
    _isAutoRestarting = true;
    _startRecordingTimer();
    notifyListeners();

    await voiceService.startListening(
      localeId: sourceLang.speechLocale,
      onPartialResult: (text) {
        inputText = text;
        notifyListeners();
      },
      onResult: (text) async {
        if (!isListening) return;
        inputText = text;
        isListening = false;
        _isAutoRestarting = false;
        _stopRecordingTimer();
        notifyListeners();

        await Future.delayed(const Duration(milliseconds: 600));
        await translate();
      },
      onServiceError: () async {
        if (_isAutoRestarting) {
          await voiceService.reset();
          if (_isAutoRestarting) toggleMic();
        }
      }
    );
  }

  void _handleVoiceError(String err) {
    final low = err.toLowerCase();
    if (!_isAutoRestarting) return;
    if (low.contains('timeout') || low.contains('no match') || low.contains('error_speech_timeout')) {
      // Uniquement pour le micro de Traduction. En conversation, le
      // push-to-talk est strict : le micro ne doit JAMAIS repartir tout
      // seul, même sur erreur — seul un nouvel appui explicite du doigt le
      // relance (voir startConversationRecording). Appeler
      // toggleConversationMic() ici casserait ce contrat.
      if (_isTranslateMode) {
        debugPrint("Auto-relaunching mic after error: $err");
        toggleMic();
      }
    }
  }

  Future<void> translate() async {
    if (inputText.trim().isEmpty) return;
    isTranslating = true;
    notifyListeners();

    if (translationService is ApiTranslationService) {
      (translationService as ApiTranslationService).accessToken = backend.accessToken;
    }

    try {
      final result = await translationService.translate(
        text: inputText,
        sourceLangCode: sourceLang.code,
        targetLangCode: targetLang.code,
      );
      outputText = result;
      lastRecordedText = inputText;
      await _addToHistory(result);

      inputText = '';
      notifyListeners();

      await speakOutput();

      if (isAuthenticated && _isTranslateMode) await toggleMic();
    } catch (error) {
      debugPrint('Translation error: $error');
      outputText = 'Erreur de traduction.';
    } finally {
      isTranslating = false;
      notifyListeners();
    }
  }

  Future<void> speakOutput() async {
    if (outputText.trim().isEmpty) return;
    await voiceService.stopListening();
    await voiceService.speak(outputText, localeId: targetLang.speechLocale);
  }

  void clear() {
    inputText = '';
    outputText = '';
    notifyListeners();
  }

  // --- Mode Conversation Face-à-face ---
  Future<void> createConversation({
    required String title,
    required String secondSpeaker,
    required String secondSpeakerLang,
  }) async {
    isSessionLoading = true;
    notifyListeners();
    try {
      final firstSpeakerName = profile?.fullName ?? 'Moi';
      final firstSpeakerLang = profile?.preferredLanguage ?? 'fr';

      activeConversation = await backend.createSameDevice(
        title: title,
        sourceLanguage: firstSpeakerLang,
        targetLanguage: secondSpeakerLang,
        firstSpeakerName: firstSpeakerName,
        secondSpeakerName: secondSpeaker,
      );

      await loadConversations();
      await openConversation(activeConversation!);
      await startConversation();
    } catch (e) {
      sessionError = "Erreur création : $e";
    } finally {
      isSessionLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadConversations() async {
    conversations = await backend.conversations();
    notifyListeners();
  }

  Future<void> openConversation(Conversation conversation) async {
    activeConversation = conversation;
    final list = await backend.speakers(conversation.id);
    speakers = list.map((s) {
      if (conversation.activeSpeakerId.isNotEmpty) {
        return s.copyWith(active: s.id == conversation.activeSpeakerId);
      }
      return s;
    }).toList();

    if (speakers.isNotEmpty && !speakers.any((s) => s.active)) {
      await activateSpeaker(speakers.first);
    }

    await refreshTimeline();
    notifyListeners();
  }

  Future<void> activateSpeaker(Speaker speaker) async {
    if (activeConversation == null) return;
    // L’alternance locale ne doit pas être bloquée par une erreur réseau.
    speakers = speakers.map((s) => s.copyWith(active: s.id == speaker.id)).toList();
    notifyListeners();
    try {
      await backend.activateSpeaker(activeConversation!.id, speaker.id);
    } catch (e) {
      debugPrint('Activation locuteur différée: $e');
    }
  }

  Future<void> _startConversationMic() async {
    if (activeConversation == null || speakers.isEmpty) return;

    _isTranslateMode = false;

    try {
      if (!voiceService.isAvailable) {
        await voiceService.init(onError: _handleVoiceError);
      }
    } catch (_) {}

    final activeSpeaker = speakers.firstWhere((s) => s.active, orElse: () => speakers.first);
    final isMe = speakers.indexOf(activeSpeaker) == 0;

    // S'assurer que la langue correspond au locuteur actif
    String langCode;
    if (isMe) {
      langCode = activeConversation!.sourceLanguage;
    } else {
      langCode = activeConversation!.targetLanguage;
    }

    final locale = AppLanguage.all.firstWhere(
      (l) => l.code == langCode,
      orElse: () => AppLanguage.french,
    ).speechLocale;

    final captureGeneration = _conversationCaptureGeneration;
    isListening = true;
    _isAutoRestarting = true;
    _startRecordingTimer();
    notifyListeners();

    // Sauvegarde temporaire systématique : que ce soit un résultat partiel
    // ou final, on garde toujours la dernière bribe reconnue dans un
    // tampon. Au relâchement du bouton, on utilise directement cette
    // valeur plutôt que d'attendre un signal "résultat final" précis du
    // moteur — cette dépendance s'est montrée peu fiable et faisait que
    // le micro ne captait plus rien.
    void saveToBuffer(String text) {
      if (captureGeneration != _conversationCaptureGeneration) return;
      if (text.trim().isEmpty) return;
      _pendingConversationText = text;
      conversationInputText = text;
      notifyListeners();
    }

    await voiceService.startListening(
      localeId: locale,
      onPartialResult: saveToBuffer,
      onResult: saveToBuffer,
      onServiceError: () async {
        if (captureGeneration != _conversationCaptureGeneration) {
          return;
        }
        if (_isAutoRestarting && !_isTranslateMode) {
          isListening = false;
          _stopRecordingTimer();
          await voiceService.reset();
        }
      }
    );
  }

  Future<void> _submitConversationText(String text) async {
    if (!_conversationScreenActive || _isTranslateMode) {
      return;
    }
    conversationInputText = text;
    isListening = false;
    _isAutoRestarting = false;
    _stopRecordingTimer();
    _setConversationMicState(ConversationMicState.translating);

    if (text.trim().isEmpty) {
      await voiceService.reset();
      _setConversationMicState(ConversationMicState.waiting);
      return;
    }

    await processTextTurn(text);
  }

  /// Démarrage contrôlé par l'appui prolongé du bouton de conversation.
  /// PARTICIPANT (A ou B) : MAINTIENT 🎤 → RECORDING.
  Future<void> startConversationRecording() async {
    if (!_conversationScreenActive ||
        (conversationMicState != ConversationMicState.idle &&
            conversationMicState != ConversationMicState.waiting)) {
      return;
    }
    // Passage synchrone à `recording` avant tout `await` : ça sert aussi
    // de verrou contre un double appui rapproché (un second appel voit
    // aussitôt que l'état n'est plus idle/waiting et s'arrête ici).
    _conversationHoldActive = true;
    _pendingConversationText = '';
    _conversationCaptureGeneration++;
    _setConversationMicState(ConversationMicState.recording);

    if (isListening || voiceService.isListening) {
      await stopAllAudio();
    }
    await voiceService.stopSpeaking();
    if (_conversationHoldActive && _conversationScreenActive) {
        await _startConversationMic();
    }
    if (!_conversationHoldActive && isListening) {
      await stopAllAudio();
    }
    // Si le doigt a été relâché pendant qu'on démarrait encore l'écoute,
    // on retombe proprement en attente plutôt que de rester bloqué sur
    // "recording".
    if (!_conversationHoldActive && conversationMicState == ConversationMicState.recording) {
      _setConversationMicState(ConversationMicState.waiting);
    }
  }

  /// PARTICIPANT : RELÂCHE 🎤 → déclenche la transcription puis la
  /// traduction.
  void stopConversationRecording() {
    if (conversationMicState != ConversationMicState.recording) return;
    _conversationHoldActive = false;
    _isAutoRestarting = false;
    conversationInputText = '';
    _setConversationMicState(ConversationMicState.processing);
    unawaited(_finishConversationRecording());
  }

  Future<void> _finishConversationRecording() async {
    await voiceService.stopListening();
    // Petit délai de grâce pour laisser une dernière bribe (partielle ou
    // finale) mettre à jour le tampon — sans dépendre d'un signal précis
    // du moteur natif. Le tampon (_pendingConversationText) est déjà
    // alimenté en continu pendant l'écoute (voir toggleConversationMic),
    // donc on peut lui faire confiance directement.
    await Future.delayed(const Duration(milliseconds: 700));
    _conversationCaptureGeneration++;

    final pending = _pendingConversationText.trim();
    _pendingConversationText = '';
    conversationInputText = '';

    if (pending.isNotEmpty && _conversationScreenActive && !_isTranslateMode) {
      await _submitConversationText(pending);
    } else {
      isListening = false;
      _stopRecordingTimer();
      _setConversationMicState(ConversationMicState.idle);
    }
  }

  Future<void> processTextTurn(String text) async {
    if (activeConversation == null || speakers.isEmpty || text.trim().isEmpty) {
      _setConversationMicState(ConversationMicState.waiting);
      return;
    }

    // FR → transcription / TR → transcription : déjà fait par le moteur
    // vocal (texte reçu en paramètre). On enchaîne directement sur l'étape
    // FR → TR / TR → FR : la traduction.
    _setConversationMicState(ConversationMicState.translating);

    final speaker = speakers.firstWhere((item) => item.active, orElse: () => speakers.first);
    final isMe = speakers.indexOf(speaker) == 0;
    final source = isMe ? activeConversation!.sourceLanguage : activeConversation!.targetLanguage;
    final target = isMe ? activeConversation!.targetLanguage : activeConversation!.sourceLanguage;

    final int turnIndex = timeline.length;
    _localOriginals[turnIndex] = text;
    lastRecordedText = text;
    conversationInputText = '';
    notifyListeners();

    String translated = '';
    try {
      final result = await backend.processTextTurn(activeConversation!.id, speaker.id, text, source, target);
      final payload = result is Map ? Map<String, dynamic>.from(result) : <String, dynamic>{};
      final data = payload['data'] ?? payload;
      final transObj = data['translation'] ?? data;
      translated = (transObj['translatedText'] ?? transObj['text'] ?? '').toString();
    } catch (e) {
      debugPrint("ProcessTextTurn error: $e");
    }

    if (speakers.length >= 2) {
      final nextSpeaker = speakers.firstWhere((s) => s.id != speaker.id);
      await activateSpeaker(nextSpeaker);
    }

    try {
      await refreshTimeline();
    } catch (e) {
      debugPrint('Rafraîchissement timeline différé: $e');
    }

    if (translated.isEmpty && timeline.isNotEmpty) {
      final last = timeline.last;
      translated = (last['translatedText'] ?? last['translation']?['translatedText'] ?? '').toString();
    }

    // 🔊 L'autre participant entend la traduction.
    if (translated.isNotEmpty) {
      _setConversationMicState(ConversationMicState.playing);
      await speakMessage(translated, target);
    }

    // Push-to-talk strict : le changement de locuteur ne doit jamais
    // démarrer son micro automatiquement. Il ne pourra écouter qu'après
    // son propre appui maintenu sur le bouton.
    _conversationHoldActive = false;
    _isAutoRestarting = false;
    await voiceService.reset();
    await voiceService.stopListening();
    isListening = false;
    _stopRecordingTimer();

    // Le participant qui vient de parler passe en attente ; le sélecteur
    // de locuteur met déjà en évidence à qui c'est le tour maintenant.
    _setConversationMicState(ConversationMicState.waiting);
  }

  Future<void> speakMessage(String text, String langCode) async {
    final locale = AppLanguage.all.firstWhere(
      (l) => l.code == langCode,
      orElse: () => AppLanguage.french,
    ).speechLocale;
    await voiceService.stopListening();
    await voiceService.speak(text, localeId: locale);
  }

  Future<void> refreshTimeline() async {
    if (activeConversation == null) return;
    timeline = await backend.timeline(activeConversation!.id);
    notifyListeners();
  }

  Future<void> deleteConversation(String id) async {
    await backend.deleteConversation(id);
    conversations.removeWhere((c) => c.id == id);
    if (activeConversation?.id == id) activeConversation = null;
    notifyListeners();
  }

  Future<void> startConversation() async => _lifecycle('start');
  Future<void> pauseConversation() async => _lifecycle('pause');
  Future<void> resumeConversation() async => _lifecycle('resume');
  Future<void> endConversation() async => _lifecycle('end');

  Future<void> _lifecycle(String action) async {
    if (activeConversation == null) return;
    await backend.lifecycle(activeConversation!.id, action);
    await loadConversations();
    try {
      activeConversation = conversations.firstWhere((c) => c.id == activeConversation!.id);
    } catch (_) {}
    await refreshTimeline();
  }

  // --- Historique ---
  final List<TranslationEntry> history = [];

  Future<void> _addToHistory(String translated) async {
    final entry = TranslationEntry(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      sourceText: inputText,
      translatedText: translated,
      sourceLangCode: sourceLang.code,
      targetLangCode: targetLang.code,
      date: DateTime.now(),
    );
    history.insert(0, entry);
    await _persistHistory();
  }

  Future<void> toggleFavorite(String id) async {
    final idx = history.indexWhere((e) => e.id == id);
    if (idx != -1) {
      history[idx] = history[idx].copyWith(isFavorite: !history[idx].isFavorite);
      notifyListeners();
      await _persistHistory();
    }
  }

  Future<void> deleteHistoryEntry(String id) async {
    history.removeWhere((e) => e.id == id);
    notifyListeners();
    await _persistHistory();
  }

  Future<void> loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('history') ?? [];
    history..clear()..addAll(raw.map((e) => TranslationEntry.fromJson(jsonDecode(e))));
    notifyListeners();
  }

  Future<void> _persistHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('history', history.map((e) => jsonEncode(e.toJson())).toList());
  }

  // --- Thème ---
  ThemeMode themeMode = ThemeMode.system;
  Future<void> loadThemePreference() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('themeMode');
    if (saved == 'dark') themeMode = ThemeMode.dark;
    if (saved == 'light') themeMode = ThemeMode.light;
    notifyListeners();
  }
  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('themeMode', mode.name);
  }

  // --- Language Packs ---
  Future<void> loadLanguagePacks({LanguagePackService? service}) async {
    final packService = service ?? LanguagePackService(
      baseUrl: 'https://api.anla.mybestsejour.com',
      accessToken: backend.accessToken,
    );
    try {
      availableLanguagePacks = await packService.fetchPacks();
      recommendedLanguagePacks = await packService.fetchRecommendedPacks();
      installedLanguagePacks = await packService.fetchInstalledPacks();
    } catch (_) {}
    notifyListeners();
  }
}
